﻿//module.exports = require('./config.' + process.env.NODE_ENV);
module.exports = require('./dev');